                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:3467236
HE3D K280 Adjustable Leveling Mount by mkellsy is licensed under the Creative Commons - Attribution license.
http://creativecommons.org/licenses/by/3.0/

# Summary

[![View on GitHub](https://img.shields.io/github/last-commit/mkellsy/reprap-delta.svg?colorB=%23999999&label=updated&logo=github&logoColor=%2364b5f6&style=popout-square)](https://github.com/mkellsy/reprap-delta)

This is a basic bed mount system. It uses all 6 mount points. To use these you will need to replace the LCD screen mount.

## Assembly
To assemble you will need;

- 12 x M4 x 8 socket head cap screws.
- 12 x M4 Hammer Nuts.
- 3 x M3 Leveling Spring Component hardware. [https://www.amazon.com/gp/product/B0761TLRNY/](https://www.amazon.com/gp/product/B0761TLRNY/)
- 3 x 7.5mm x 20mm bed leveling springs. [https://www.amazon.com/dp/B01HO33RBY/](https://www.amazon.com/dp/B01HO33RBY/)
- 3 x M3 x 25 socket head cap screws.
- 3 x M3 nylock nuts.

## Updates

### 3/7/2019
- Removed the plastic nuts and replaced them with M3 nylock nuts.

### 3/5/2019 Update.
- Modified 3 feet to allow for a plunger. Only 3 points need leveling, any more and you can warp the bed.
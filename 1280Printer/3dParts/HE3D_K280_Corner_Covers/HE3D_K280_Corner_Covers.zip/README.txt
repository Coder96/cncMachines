                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:3504402
HE3D K280 Corner Covers by mkellsy is licensed under the Creative Commons - Attribution license.
http://creativecommons.org/licenses/by/3.0/

# Summary

[![View on GitHub](https://img.shields.io/github/last-commit/mkellsy/reprap-delta.svg?colorB=%23999999&label=updated&logo=github&logoColor=%2364b5f6&style=popout-square)](https://github.com/mkellsy/reprap-delta)

These simply press into the corners on the HE3D K280 to hide the steppers and wires. This requires no hardware.

This works well with the bed mounts from found here [https://www.thingiverse.com/thing:3467236](https://www.thingiverse.com/thing:3467236). This will align the mounts perfectly.

The corner supports can be found here [https://www.thingiverse.com/thing:3478173](https://www.thingiverse.com/thing:3478173).

The touchscreen housing can be found here [https://www.thingiverse.com/thing:3467548](https://www.thingiverse.com/thing:3467548).

## Assembly
To assemble you will need;

- A Small Rubber Mallet Helps (Not Required)
                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:2155251
Modular carriages for 4020 v-slot (for d3m-bot, d-bot, c-bot) by _MSA_ is licensed under the Creative Commons - Attribution - Non-Commercial - Share Alike license.
http://creativecommons.org/licenses/by-nc-sa/3.0/

# Summary

Modular carriages X Y Z for 40x20 mod for V Slot rails with Solid V Wheels (openbuilds). It was redesigned from http://www.thingiverse.com/thing:1839201 
It is used now for my own D3M-Bot (remix of original D-bot http://www.thingiverse.com/thing:1001065) 

Carriages is suppose to use 3 wheels - Solid V Wheels (openbuilds) 24mm (bigger then in original D-Bot/C-Bot). The 3rd wheel is to be tightened by top bolt. (so just screw tension instead of eccentric nuts)
Use nuts with nylon inserts locking to fix wheels

X carriage has prebuilded GT2 mount places (use belt clamb from http://www.thingiverse.com/thing:1001065)

Y carriage has 2 variants to be used without or with LED strip (was remixed from D-bot)

Z carriage has 2 variants with shoter bolts and longer

Parts for X and Y carriages interchangeable. Z  carriage has own.

Build guide and materials to be defined soon. 
(Temporary use as refrence instruction and materials list from http://www.thingiverse.com/thing:1839201 )
There is only one difference: for single Z carriage I've used additionaly 1x60mm and 2x50mm M5 bolts for wheels.  To fix wheels on bolts use M5 nuts with nylon locks

Just finished setup - looks & works like a tank :)

Update 24.03.2017: Added mount block for  e3d hotend in files mbot_e3d_m1v2.stl, 
mbot_e3d_m2.stl It has optional mount for fan. 
The file   mbot-radialfan-mount.stl  and bot-radialfan-flow.stl is radial fan 50x15 mount and flow corrector

Update 18.03.2017: Steps file added